var inputFirst = document.getElementById('first');
var inputSecond = document.getElementById('second');
var inputThird = document.getElementById('third');
var inputFourth = document.getElementById('fourth');
var img = document.querySelector('.img-borda img');
var inputNome = document.getElementById('nome');
var inputParido = document.getElementById('partido');

//// AUTOTAB
function autotab(original, destination) {
    if (original.getAttribute && original.value.length == original.getAttribute("maxlength"))
        destination.focus()
}

////// CONFIRMA
function confirma() {

    var first = inputFirst.value;
    var second = inputSecond.value;
    var third = inputThird.value;
    var fourth = inputFourth.value;
    var inputConjunto = (first + second + third + fourth);

    limpa();

    switch (inputConjunto) {

        /////// 2B

        case '67':
            img.src = './img/MAD/presidente/tiago.jpeg';
            inputNome.value = 'Tiago do Vale de Oliveira';
            inputParido.value = 'MAD';
            break;

        case '6748':
            img.src = './img/MAD/caioE.jpeg';
            inputNome.value = 'Caio Eduardo de Espindola';
            inputParido.value = 'MAD';
            break;

        case '6778':
            img.src = './img/MAD/vitorC.jpeg';
            inputNome.value = 'Vitor Lostada da Cunha';
            inputParido.value = 'MAD';
            break;

        case '6726':
            img.src = './img/MAD/samuel.jpeg';
            inputNome.value = 'Samuel de Sousa Araujo Silva';
            inputParido.value = 'MAD';
            break;

        case '42':
            img.src = './img/PLB/presidente/matheusM.jpeg';
            inputNome.value = 'Matheus Marcos Espindola';
            inputParido.value = 'PLB';
            break;

        case '4224':
            img.src = './img/PLB/luiz.jpeg';
            inputNome.value = 'Luiz Gustavo da Silva Penachin';
            inputParido.value = 'PLB';
            break;

        case '4242':
            img.src = './img/PLB/pedro.jpeg';
            inputNome.value = 'Pedro Valentin Dutra';
            inputParido.value = 'PLB';
            break;

        case '4222':
            img.src = './img/PLB/joaoB.jpeg';
            inputNome.value = 'João Vitor Schwambach Brasil';
            inputParido.value = 'PLB';
            break;

        case '69':
            img.src = './img/PBM/presidente/mateusS.jpeg';
            inputNome.value = 'Mateus Salgado Barboza Costa';
            inputParido.value = 'PBM';
            break;

        case '6969':
            img.src = './img/PBM/gabrielZ.jpeg';
            inputNome.value = 'Gabriel Zatorski';
            inputParido.value = 'PBM';
            break;

        case '6996':
            img.src = './img/PBM/joaoP.jpeg';
            inputNome.value = 'João Pedro Philippi Ferreira';
            inputParido.value = 'PBM';
            
            break;

        case '6966':
            img.src = './img/PBM/arthur.jpeg';
            inputNome.value = 'Arthur George da Silva';
            inputParido.value = 'PBM';
            break;

        case '24':
            img.src = './img/PJ/presidente/gabrielaT.jpeg';
            inputNome.value = 'Gabriela Thiesen';
            inputParido.value = 'PJ';
            break;

        case '2403':
            img.src = './img/PJ/giulia.jpeg';
            inputNome.value = 'Giulia Sbors Pereira';
            inputParido.value = 'PJ';
            break;

        case '2420':
            img.src = './img/PJ/lucasB.jpeg';
            inputNome.value = 'Lucas Belli da Silva';
            inputParido.value = 'PJ';
            break;

        case '2442':
            img.src = './img/PJ/sophia.jpeg';
            inputNome.value = 'Sophia Graccioli Marçal Salvan';
            inputParido.value = 'PJ';
            break;

        case '39':
            img.src = './img/PLCJ/presidente/caioG.jpeg';
            inputNome.value = 'Caio Guerra Marba Santos';
            inputParido.value = 'PLCJ';
            break;

        case '3911':
            img.src = './img/PLCJ/gabrielS.jpeg';
            inputNome.value = 'Gabriel de Souza';
            inputParido.value = 'PLCJ';
            break;

        case '3995':
            img.src = './img/PLCJ/kaue.jpeg';
            inputNome.value = 'Kauê Luiz de Borba';
            inputParido.value = 'PLCJ';
            break;

        case '3947':
            img.src = './img/PLCJ/theo.jpeg';
            inputNome.value = 'Théo Andrade Thiesen';
            inputParido.value = 'PLCJ';
            break;

        case '98':
            img.src = './img/PDM/presidente/isadora.jpeg';
            inputNome.value = 'Isadora Roman da Silva';
            inputParido.value = 'PDM';
            break;

        case '9898':
            img.src = './img/PDM/ana.jpeg';
            inputNome.value = 'Ana Elisa Rieg Dias';
            inputParido.value = 'PDM';
            break;

        case '9828':
            img.src = './img/PDM/gabrielaO.jpeg';
            inputNome.value = 'Gabriela Oliveira da Silva';
            inputParido.value = 'PDM';
            break;

        case '9858':
            img.src = './img/PDM/natalia.jpeg';
            inputNome.value = 'Natalia Maria Luz';
            inputParido.value = 'PDM';
            break;

        case '26':
            img.src = './img/MMCB/presidente/vitorM.jpeg';
            inputNome.value = 'Vitor Menezes Grando';
            inputParido.value = 'MMCB';
            break;

        case '2602':
            img.src = './img/MMCB/beatriz.jpeg';
            inputNome.value = 'Beatriz Inacio Martins';
            inputParido.value = 'MMCB';
            break;

        case '2603':
            img.src = './img/MMCB/carol.jpeg';
            inputNome.value = 'Carolina Ribeiro Nuernberg';
            inputParido.value = 'MMCB';
            break;

        case '2604':
            img.src = './img/MMCB/maria.jpeg';
            inputNome.value = 'Maria Eduarda Longo';
            inputParido.value = 'MMCB';
            break;

        case '87':
            img.src = './img/PCLdB/presidente/gabrielL.jpeg';
            inputNome.value = 'Gabriel de Souza Leal';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            break;

        case '8707':
            img.src = './img/PCLdB/yan.jpg';
            inputNome.value = 'Yan Carlos Souza Moraes';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            break;

        case '8776':
            img.src = './img/PCLdB/nicolas.jpg';
            inputNome.value = 'Nycolas Padilha Pinheiro';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            break;

        case '8712':
            img.src = './img/PCLdB/robson.jpg';
            inputNome.value = 'Robson Vitor Silva da Silva';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            break;

        ///////// 2A

        case '37':
            img.src = './img/PSDD/presidente/matheusA.jpg';

            break;

        case '3714':
            img.src = './img/PSDD/nathalia.jpg';

            break;

        case '3713':
            img.src = './img/PSDD/antonio.jpg';

            break;

        case '3731':
            img.src = './img/PSDD/juliaC.jpg';

            break;

        case '66':
            img.src = './img/PCA/presidente/lucasO.jpg';

            break;

        case '6660':
            img.src = './img/PCA/arthurD.jpg';

            break;

        case '6669':
            img.src = './img/PCA/lucasN.jpg';

            break;

        case '6699':
            img.src = './img/PCA/thomas.jpg';
            break;

        case '49':
            img.src = './img/PRD/presidente/camila.jpg';
            break;

        case '4925':
            img.src = './img/PRD/marcus.jpg';
            break;

        case '4911':
            img.src = './img/PRD/juliaT.jpg';
            break;

        case '4913':
            img.src = './img/PRD/barbara.jpg';
            break;

        case '57':
            img.src = './img/PDL/presidente/ricardo.jpg';
            break;

        case '5705':
            img.src = './img/PDL/luana.jpg';
            break;

        case '5769':
            img.src = './img/PDL/matheusP.jpg';
            break;

        case '5701':
            img.src = './img/PDL/andre.jpg';
            break;


        case '97':
            img.src = './img/FNB/presidente/jefferson.jpg';
            break;


        case '9766':
            img.src = './img/FNB/marcosH.jpg';
            break;


        case '9723':
            img.src = './img/FNB/lucasM.jpg';
            break;

        case '9788':
            img.src = './img/FNB/miguel.jpg';
            break;

        case '':
            img.src = './img/PLIE/presidente/daviL.jpg';
            break;

        case '':
            img.src = './img/PLIE/gabriel.jpg';
            break;

        case '':
            img.src = './img/PLIE/mateusN.jpg';
            break;

        case '':
            img.src = './img/PLIE/reinaldo.jpg';
            break;

        case '':
            img.src = './img/PRL/gabrielaG.jpg';
            break;

        case '':
            img.src = './img/PRL/isabela.jpg';
            break;

        case '':
            img.src = './img/PRL/joaoS.jpg';
            break;

        case '':
            img.src = './img/PLIE/vitorN.jpg';
            break;

        case '0000':
            img.src = './img/limpa/branco.png';
            alert("Voto nulo.");
            break;

        default:
            img.src = './img/limpa/branco.png';
            alert("Candidato inexistente.")
            break;
    }
}


/////// BRANCO
function branco() {

    var inputConjunto = "branco";
    alert("Voto branco.");
    console.log(inputConjunto);
    limpa();
}

////// CANCELA
function limpa() {
    inputFirst.value = "";
    inputSecond.value = "";
    inputThird.value = "";
    inputFourth.value = "";
    inputNome.value = "";
    inputParido.value = "";

    img.src = './img/limpa/branco.png';

}


///// ENVIAR

function enviar() {


}

//////////// VISUALIZAR

function visualizar() {

    var first = inputFirst.value;
    var second = inputSecond.value;
    var third = inputThird.value;
    var fourth = inputFourth.value;

    var inputConjunto = (first + second + third + fourth);
    switch (inputConjunto) {

        /////// 2B

        case '67':
            img.src = './img/MAD/presidente/tiago.jpeg';
            inputNome.value = 'Tiago do Vale de Oliveira';
            inputParido.value = 'MAD';
            break;

        case '6748':
            img.src = './img/MAD/caioE.jpeg';
            inputNome.value = 'Caio Eduardo de Espindola';
            inputParido.value = 'MAD';
            break;

        case '6778':
            img.src = './img/MAD/vitorC.jpeg';
            inputNome.value = 'Vitor Lostada da Cunha';
            inputParido.value = 'MAD';
            break;

        case '6726':
            img.src = './img/MAD/samuel.jpeg';
            inputNome.value = 'Samuel de Sousa Araujo Silva';
            inputParido.value = 'MAD';
            break;

        case '42':
            img.src = './img/PLB/presidente/matheusM.jpeg';
            inputNome.value = 'Matheus Marcos Espindola';
            inputParido.value = 'PLB';
            break;

        case '4224':
            img.src = './img/PLB/luiz.jpeg';
            inputNome.value = 'Luiz Gustavo da Silva Penachin';
            inputParido.value = 'PLB';
            break;

        case '4242':
            img.src = './img/PLB/pedro.jpeg';
            inputNome.value = 'Pedro Valentin Dutra';
            inputParido.value = 'PLB';
            break;

        case '4222':
            img.src = './img/PLB/joaoB.jpeg';
            inputNome.value = 'João Vitor Schwambach Brasil';
            inputParido.value = 'PLB';
            break;

        case '69':
            img.src = './img/PBM/presidente/mateusS.jpeg';
            inputNome.value = 'Mateus Salgado Barboza Costa';
            inputParido.value = 'PBM';
            break;

        case '6969':
            img.src = './img/PBM/gabrielZ.jpeg';
            inputNome.value = 'Gabriel Zatorski';
            inputParido.value = 'PBM';
            break;

        case '6996':
            img.src = './img/PBM/joaoP.jpeg';
            inputNome.value = 'João Pedro Philippi Ferreira';
            inputParido.value = 'PBM';
            
            break;

        case '6966':
            img.src = './img/PBM/arthur.jpeg';
            inputNome.value = 'Arthur George da Silva';
            inputParido.value = 'PBM';
            break;

        case '24':
            img.src = './img/PJ/presidente/gabrielaT.jpeg';
            inputNome.value = 'Gabriela Thiesen';
            inputParido.value = 'PJ';
            break;

        case '2403':
            img.src = './img/PJ/giulia.jpeg';
            inputNome.value = 'Giulia Sbors Pereira';
            inputParido.value = 'PJ';
            break;

        case '2420':
            img.src = './img/PJ/lucasB.jpeg';
            inputNome.value = 'Lucas Belli da Silva';
            inputParido.value = 'PJ';
            break;

        case '2442':
            img.src = './img/PJ/sophia.jpeg';
            inputNome.value = 'Sophia Graccioli Marçal Salvan';
            inputParido.value = 'PJ';
            break;

        case '39':
            img.src = './img/PLCJ/presidente/caioG.jpeg';
            inputNome.value = 'Caio Guerra Marba Santos';
            inputParido.value = 'PLCJ';
            break;

        case '3911':
            img.src = './img/PLCJ/gabrielS.jpeg';
            inputNome.value = 'Gabriel de Souza';
            inputParido.value = 'PLCJ';
            break;

        case '3995':
            img.src = './img/PLCJ/kaue.jpeg';
            inputNome.value = 'Kauê Luiz de Borba';
            inputParido.value = 'PLCJ';
            break;

        case '3947':
            img.src = './img/PLCJ/theo.jpeg';
            inputNome.value = 'Théo Andrade Thiesen';
            inputParido.value = 'PLCJ';
            break;

        case '98':
            img.src = './img/PDM/presidente/isadora.jpeg';
            inputNome.value = 'Isadora Roman da Silva';
            inputParido.value = 'PDM';
            break;

        case '9898':
            img.src = './img/PDM/ana.jpeg';
            inputNome.value = 'Ana Elisa Rieg Dias';
            inputParido.value = 'PDM';
            break;

        case '9828':
            img.src = './img/PDM/gabrielaO.jpeg';
            inputNome.value = 'Gabriela Oliveira da Silva';
            inputParido.value = 'PDM';
            break;

        case '9858':
            img.src = './img/PDM/natalia.jpeg';
            inputNome.value = 'Natalia Maria Luz';
            inputParido.value = 'PDM';
            break;

        case '26':
            img.src = './img/MMCB/presidente/vitorM.jpeg';
            inputNome.value = 'Vitor Menezes Grando';
            inputParido.value = 'MMCB';
            break;

        case '2602':
            img.src = './img/MMCB/beatriz.jpeg';
            inputNome.value = 'Beatriz Inacio Martins';
            inputParido.value = 'MMCB';
            break;

        case '2603':
            img.src = './img/MMCB/carol.jpeg';
            inputNome.value = 'Carolina Ribeiro Nuernberg';
            inputParido.value = 'MMCB';
            break;

        case '2604':
            img.src = './img/MMCB/maria.jpeg';
            inputNome.value = 'Maria Eduarda Longo';
            inputParido.value = 'MMCB';
            break;

        case '87':
            img.src = './img/PCLdB/presidente/gabrielL.jpeg';
            inputNome.value = 'Gabriel de Souza Leal';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            break;

        case '8707':
            img.src = './img/PCLdB/yan.jpg';
            inputNome.value = 'Yan Carlos Souza Moraes';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            break;

        case '8776':
            img.src = './img/PCLdB/nicolas.jpg';
            inputNome.value = 'Nycolas Padilha Pinheiro';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            break;

        case '8712':
            img.src = './img/PCLdB/robson.jpg';
            inputNome.value = 'Robson Vitor Silva da Silva';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            break;

        ///////// 2A

        case '37':
            img.src = './img/PSDD/presidente/matheusA.jpg';
            inputNome.value = '';
            inputParido.value = 'PSDD';
            break;

        case '3714':
            img.src = './img/PSDD/nathalia.jpg';
            inputNome.value = '';
            inputParido.value = 'PSDD';
            break;

        case '3713':
            img.src = './img/PSDD/antonio.jpg';

            break;

        case '3731':
            img.src = './img/PSDD/juliaC.jpg';

            break;

        case '66':
            img.src = './img/PCA/presidente/lucasO.jpg';

            break;

        case '6660':
            img.src = './img/PCA/arthurD.jpg';

            break;

        case '6669':
            img.src = './img/PCA/lucasN.jpg';

            break;

        case '6699':
            img.src = './img/PCA/thomas.jpg';
            break;

        case '49':
            img.src = './img/PRD/presidente/camila.jpg';
            break;

        case '4925':
            img.src = './img/PRD/marcus.jpg';
            break;

        case '4911':
            img.src = './img/PRD/juliaT.jpg';
            break;

        case '4913':
            img.src = './img/PRD/barbara.jpg';
            break;

        case '57':
            img.src = './img/PDL/presidente/ricardo.jpg';
            break;

        case '5705':
            img.src = './img/PDL/luana.jpg';
            break;

        case '5769':
            img.src = './img/PDL/matheusP.jpg';
            break;

        case '5701':
            img.src = './img/PDL/andre.jpg';
            break;

        case '97':
            img.src = './img/FNB/presidente/jefferson.jpg';
            break;

        case '9766':
            img.src = './img/FNB/marcosH.jpg';
            break;

        case '9723':
            img.src = './img/FNB/lucasM.jpg';
            break;

        case '9788':
            img.src = './img/FNB/miguel.jpg';
            break;

        case '0000':
            img.src = './img/limpa/branco.png';
            alert("Voto nulo, imagem inexistente.");
            break; 

            default:
            img.src = './img/limpa/branco.png';
            alert("Inexistente.")
            break;
    }
}